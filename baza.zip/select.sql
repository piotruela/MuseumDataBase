--Magazyny oddalone dalej niż wynosi średnia odległość magazynów od muzuem

CREATE VIEW [Magazyn lezace daleko od muzeum] AS
SELECT idMagazynu, odlegloscOdMuzuem
FROM Magazyn
WHERE odlegloscOdMuzuem > (SELECT AVG(odlegloscOdMuzuem) FROM Magazyn);


--Wystawy, które jeszcze się nie odbyły

SELECT nazwa, dataWernisazu
FROM Wystawa
WHERE dataWernisazu > CONVERT(DATE, CURRENT_TIMESTAMP)
ORDER BY dataWernisazu, nazwa


--Dzieła i prace, którym zostały poddane

SELECT Dzielo.nazwa, Dzielo.rokWykonania, Praca.rodzajPracy, Praca.rzeczywistaDataZakonczenia
FROM Dzielo
JOIN Praca ON Praca.idDziela=Dzielo.idDziela


--Najbardziej wartościowe dzieła z danej epoki

SELECT Epoka.nazwa, COUNT(Dzielo.idEpoki) AS ile FROM Dzielo
LEFT JOIN Epoka ON Dzielo.idEpoki = Epoka.idEpoki
GROUP BY Epoka.nazwa;


--Najbardziej wartościowe dzieła z danej epoki

SELECT OuterDzielo.nazwa, rokWykonania, wlasciciel, wartosc, Epoka.nazwa
FROM Dzielo AS OuterDzielo
LEFT JOIN Epoka ON Epoka.idEpoki=OuterDzielo.idEpoki
WHERE wartosc = (SELECT MAX(wartosc) FROM Dzielo
				 WHERE   idEpoki=OuterDzielo.idEpoki)
				 
				 
--Kraje i iloscKontrahentow w danym państwie

SELECT kraj, COUNT(kraj) AS ileKontrahentow
FROM Kontrahent
GROUP BY kraj
ORDER BY ileKontrahentow DESC


--Pracownie które są czynne obecnie i nie są pełne

SELECT idPracowni, czynnaOd, czynnaDo
FROM Pracownia
WHERE czynnaDo > CONVERT(TIME, CURRENT_TIMESTAMP) AND pelne = 0