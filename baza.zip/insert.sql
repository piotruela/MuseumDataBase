use Muzeum;
set dateformat dmy;

insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)
	values(0, 'Sztuka starożytnego Egiptu', 'Cechuje ją jedność artystycznych form, ciągłość rozwoju oraz funkcja służebne wobec władców i religi',
	-4000, 400)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)
	values(1, 'Sztuka starożytnej Grecji', 'Mianem tej sztuki określa się twórczość Greków na Półwyspie Bałkańskim, wyspach Morza Egejskiego, w Azji Mniejszej, południowej Italii, na Sycylii oraz wybrzeżach Morza Śródziemnego i Czarnego. Poprzedziła ją sztuka mykeńska.',
	-1200,100)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)
	values(2, 'Sztuka starożytnego Rzymu', 'Jest to sztuka państwa rzymskiego: miasta - Rzymu, prowincji oraz Italii. Sztuka ta podatna była na różnorakie wpływy: w okresie królewskim dominowały wpływy sztuki etruskiej; w czasie republikańskim zaczęły napływać kanony greckie, a styl obowiązujący w cesarstwie był zlepkiem kultury hellenistycznej z tą, panującą na prowincjach rzymskich.',
	-600, 400)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)
	values(3, 'Renesans', 'Popularne stały się postacie biblijne i mitologiczne. Powstało tam malarstwo portretowe. Inspiracja dla malarzy była natura, którą obserwowali, oraz sztuka starożytna.',
	1452, 1600)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)
	values(4, 'Barok', 'Malarze baroku podejmowali najczęściej tematykę religijną, mitologiczną, alegoryczną, historyczną i portretową. Popularność zaczęły zdobywać pejzaże, sceny rodzajowe i martwe natury. Stosowano chętnie światłocień, bogatą symbolikę i efektowny iluzjonizm.',
	1580, 1730)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)	
	values(5, 'Rokoko', 'W malarstwie pojawiła się stylistyka zupełnie inna od barokowej. Zmieniła się tematyka, technika, barwy, format. Obrazy były malowane lekko i finezyjnie; kolorystyka jest jasna. Nadal powstawały obrazy mitologiczne, ale najczęściej zamiast Zeusa, Hery i Ateny, pojawiali się bogowie miłości: Afrodyta i Eros oraz Dionizos',
	1720, 1780)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)	
	values(6, 'Sentymentalizm', 'Kierunek umysłowy i literacki w Europie, który trwał od lat 70. XVIII wieku do początku wieku XIX, był okresem pomiędzy oświeceniem a romantyzmem',
	1780, 1800)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)	
	values(7, 'Klasycyzm', 'Malarstwo wyraziło się głównie w tematyce historycznej (starożytnej), mitologicznej, alegorycznej i portrecie. Jej główne cechy to wzniosłość, kontur i gładka faktura',
	1700, 1800)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)	
	values(8, 'Romantyzm', 'Romantyzm to szeroki i wieloznaczny termin stosowany do różnych przejawów sztuki. Nie ma cech odrębnego stylu, jest raczej wyrazem podstawy uczuciowej i artystycznej. Źródłami nowych tematów stały się mitologie celtyckie, germańskie, ludowe podania, narodowe legendy, poezja nieklasyczna i współczesna.',
	1760, 1850)
insert into Epoka
	(idEpoki, nazwa, opis, rokRozpoczecia, rokZakonczenia)	
	values(9, 'Realizm', 'Obrazy realistyczne to głównie sceny rodzajowe z życia prostych ludzi, namalowane przy pomocy uproszczonych środków wyrazu, o spokojnej palecie i kompozycji.',
	1800, 1900)
	
	
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(0, 'Alessandro','di Mariano Filipepi', 0, '01.03.1445', '17.05.1510')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(1, 'Leonardo', 'di ser Piere da Vinci', 0, '15.06.1452', '02.05.1519')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(2, 'Michelangelo', 'da Caravaggio', 0, '20.09.1571', '18.07.1610')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(3, 'Giovanni','Bernini', 0, '07.12.1598', '28.11.1680')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(4, 'Rembrandt','van Rijn', 0, '15.07.1606', '4.10.1669')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(5, 'François','Boucher ', 0, '29.09.1703', '30.05.1770')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(6, 'Jacques','David', 0, '30.08.1748', '29.12.1825')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(7, 'Jean','Frogonard', 0, '05.04.1732', '22.08.1806')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(8, 'Johann Heinrich','Füssli', 0, '07.04.1732', '16.04.1825')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(9, 'Apoloniusz','Kędzierski', 0, '01.07.1861', '21.09.1939')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(10, 'Teodor','Axentowicz', 0, '13.05.1859', '26.08.1938')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(11, 'Jean-Babtiste','Corot', 0, '26.07.1796', '22.02.1875')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(12, 'Jackson', 'Pollock', 0, '28.11.1912', '11.08.1956')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(13, 'Magdalena', 'Abakanowicz', 0, '20.06.1930', '20.04.2017')
insert into Autor
	(idAutora, imie, nazwisko, zyje, dataUrodzenia, dataSmierci)
	values(14, 'Barnett', 'Newman', 0, '29.01.1905', '4.07.1970')
	
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(0, 1787, 'Śmierć Skoratesa', 500000000, 'Muzuem Sztuk Pięknych', 0, 7)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(1, 1485, 'Narodziny Wenus', 680000000, 'Muzuem Sztuk Pięknych', 0, 3)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(2, 1513, 'Jan Chrzciciel', 900000000, 'Muzuem Sztuk Pięknych', 0, 3)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(3, 1601, 'Wieczerza w Emmaus', 410000000, 'Muzuem Sztuk Pięknych', 0, 4)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(4, 1650, 'Ekstaza świętej Teresy', 15000000, 'Muzuem Sztuk Pięknych', 0, 4)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(5, 1632, 'Lekcja anatomii doktora Tulpa', 21000000, 'Muzuem Sztuk Pięknych', 0, 4)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(6, 1740, 'The Triumph of Venus', 1300000, 'Nationalmuseum Sweden', 0, 5)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(7, 1767, 'The Swing', 13000000, 'Wallace Collection', 0, 5)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(8, 1781, 'Nocna mara', 17000000, 'Detroit Institute of Arts', 0, 8)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(9, 1879, 'Żydzi przed karczmą', 400000, 'Muzuem Sztuk Pięknych', 0, 6)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(10, 1906, 'Portret damy w czarnej sukni', 350000, 'Muzuem Sztuk Pięknych', 0, 6)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(11, 1826, 'The Bridge at Narni', 60000000, 'Muzuem Sztuk Pięknych', 0, 9)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(12, 1950, 'Rytm Jesieni', 650000000, 'Metropolitan Museum of Art', 0, 9)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(13, 1986, 'Cage', 16500000, 'Museum of Fine Arts, Budapest', 0, 9)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(14, 1953, 'Onement VI', 43840000, 'Gerhard Richter', 0, 9)
insert into Dzielo 
	(idDziela, rokWykonania, nazwa, wartosc, wlasciciel, zniszczonePermanentnie, idEpoki)
	values(15, 1952, 'Blue Poles', 45680000, 'Muzuem Sztuk Pięknych', 0, 9)
	
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(0, 6)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(1, 0)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(2, 1)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(3, 2)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(4, 3)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(5, 4)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(6, 5)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(7, 7)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(8, 8)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(9, 9)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(10, 10)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(11, 11)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(12, 12)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(13, 13)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(14, 14)
insert into Autor2Dzielo
	(idDziela, idAutora)
	values(15, 12)
	
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(0, 250, 0, '9:00:00', '15:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(1, 60, 0, '8:00:00', '13:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(2, 40, 0, '10:00:00', '16:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(3, 65, 0, '6:00:00', '10:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(4, 200, 0, '13:30:00', '20:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(5, 60, 0, '8:00:00', '13:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(6, 90, 0, '6:00:00', '21:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(7, 85, 0, '8:00:00', '2:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(8, 100, 0, '11:30:00', '13:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(9, 120, 0, '12:30:00', '14:00:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(10, 50, 0, '8:00:00', '16:30:00')
insert into Pracownia
	(idPracowni, powierzchnia, pelne, czynnaOd, czynnaDo)
	values(11, 750, 0, '7:00:00', '17:30:00')
	
	
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(0, 'Sztuka po 1800 roku', '01.04.2013', '10.10.2013', '9:00:00', '17:00:00', 5304)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(1, 'Przekrój sztuki polskiej', '01.04.2019', '10.08.2019', '9:00:00', '16:00:00', 0)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(2, 'Klasycyzm czy sentymentalizm?','09.12.2015', '01.01.2016', '10:00:00', '19:00:00', 3540)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(3, 'Renesans w malarstwie','05.06.2016', '21.06.2016', '7:00:00', '20:00:00', 5304)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(4, 'Rokoko', '16.08.2020', '29.09.2020', '9:00:00', '17:00:00', 0)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(5, 'Francuscy artyści', '01.04.2019', '10.12.2019', '13:00:00', '20:00:00', 0)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(6, 'Ikony sztuki', '15.05.2015', '08.10.2015', '10:00:00', '15:00:00', 4804)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(7, 'Sztuka Grecji i o Grecji', '30.01.2010', '07.07.2011', '8:00:00', '18:00:00', 53040)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(8, 'Sztuka Baroku', '16.08.2012', '16.07.2013', '9:00:00', '17:00:00', 53044)
insert into Wystawa
	(idWystawy, nazwa, dataWernisazu, dataZakonczeniaWystawy, godzinaOtwarcia, godzinaZamkniecia, iloscOdwiedzajacych)
	values(9, 'Realizm, sztuka nowoczesna', '07.07.2007',  '10.10.2010', '11:00:00', '21:00:00', 53040)
	
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(0, 'Museum of Fine Arts, Budapest', 'Budapeszt', 'Węgry', 'p')	
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(1, 'Tate Modern', 'Londyn', 'Anglia', 'p')	
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(2, 'Muzeum Narodowe w Warszawie', 'Warszawa', 'Polska', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(3, 'Galeria Ether', 'Warszawa', 'Polska', 'w')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(4, 'Luwr', 'Paryż', 'Francja', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(5, 'Muzuem Prado', 'Milan', 'Włochy', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(6, 'Muzuem Brytyjskie', 'Londyn', 'Anglia', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(7, 'Galeria Uffizi', 'Florencja', 'Włochy', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(8, 'Muzuem Egipskie', 'Kair', 'Egipt', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(9, 'The Smithsonian Institute', 'Waszyngton', 'USA', 'p')
insert into Kontrahent
	(idKontrahenta, nazwaInstytucja, miasto, kraj, typInstytucji)
	values(10, 'Rijksmuseum', 'Amsterdam', 'Holandia', 'p')
	
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(0, 2000, 40, 0, '05.05.2000')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(1, 2200, 240, 0, '05.05.2006')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(2, 1800, 140, 0, '04.08.2005')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(3, 1500, 150, 1, '12.05.2004')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(4, 7500, 460, 0, '21.07.2015')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(5, 2000, 750, 0, '01.04.2014')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(6, 2000, 410, 1, '15.12.2003')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(7, 2000, 10, 0, '23.11.2004')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(8, 2000, 90, 0, '15.12.2006')
insert into Magazyn
	(idMagazynu, powierzchnia, odlegloscOdMuzuem, pelne, dataRozpoczeciaWspolpracy)
	values(9, 2000, 480, 0, '11.11.2001')
	
insert into Praca
	(idPracy, idDziela, idPracowni, planowanaDataRozpoczecia, planowanaDataZakonczenia, rzeczywistaDataRozpoczecia, 
	rzeczywistaDataZakonczenia, planowanyCzasTrwania, rzeczywistyCzasTrwania, koszt, rodzajPracy, wToku, skutek)
	values (0, 2, 2, '10.04.2013', '15.05.2013', '10.04.2013', '15.05.2013', 35, 35, 5000, 'Konserwacja', 0, 'Sukces')
insert into Praca
	values (1, 3, 1, '10.04.2019', '15.04.2019', NULL, NULL, 5, NULL, 1500, 'Konserwacja', 0, 'Brak')
insert into Praca
	values (2, 3, 1, '17.04.2013', '20.04.2013', '17.04.2013', '25.04.2013', 3, 8, 1530, 'Restauracja', 0, 'Sukces')
insert into Praca
	values (3, 0, 2, '10.10.2012', '15.10.2012', '10.10.2012', '15.10.2012', 5, 5, 500, 'Konserwacja', 0, 'Sukces')
insert into Praca
	values (4, 4, 5, '10.01.2016', '30.01.2016', '10.01.2016', '30.01.2016', 20, 20, 570, 'Konserwacja', 0, 'Niepowodzenie; dzielo wrocilo w niezmienionym stanie')
insert into Praca
	values (5, 5, 2, '07.03.2010', '21.03.2010', '07.04.2013', '21.04.2013', 14, 14, 2300, 'Restauracja', 0, 'Sukces')
insert into Praca
	values (6, 6, 9, '19.12.2017', '12.01.2018', '19.12.2017', '12.01.2018', 24, 24, 5080, 'Restauracja', 0, 'Sukces')
insert into Praca
	values (7, 9, 6, '08.08.2020', '08.09.2020', NULL, NULL, 30, NULL, 1850, 'Konserwacja', 0,'Brak')
insert into Praca
	values (8, 11, 8, '21.12.2021', '30.12.2021', NULL, NULL, 9, NULL, 500, 'Konserwacja', 0,'Brak')
insert into Praca
	values (9, 10, 7, '10.04.2012', '15.05.2012', '10.04.2012', '15.05.2012', 35, 35, 3500, 'Konserwacja', 0, 'Sukces')
insert into Praca
	values (10, 8, 6, '16.06.2013', '20.06.2013', '16.06.2013', '17.06.2013', 4, 1, 0, 'Restauracja', 0, 'Pracowania nie posiadala niezbednych narzedzi; zwrocila dzielo w niezmienionym stanie')
	

insert into Wystawione 
	(idWystawienia,idDziela, idWystawy,  planowanaDataRozpoczecia, planowanaDataZakonczenia, rzeczywistaDataRozpoczecia, 
	rzeczywistaDataZakonczenia, planowanyCzasTrwania, rzeczywistyCzasTrwania)
	values(0, 9, 0,'01.04.2013', '10.10.2013','01.04.2013', '10.10.2013', 180, 180)
insert into Wystawione 
	values(1, 10, 0,'01.04.2013', '10.10.2013','01.04.2013', '10.10.2013', 180, 180)
insert into Wystawione 
	values(2, 14, 0,'01.04.2013', '10.10.2013','01.04.2013', '10.10.2013', 180, 180)
insert into Wystawione 
	values(3, 13, 0,'01.04.2013', '10.10.2013','01.04.2013', '10.10.2013', 180, 180)
insert into Wystawione 
	values(4, 9, 2,'09.12.2015', '01.01.2016','09.12.2015', '01.01.2016', 23, 23)
insert into Wystawione 
	values(5, 10, 2,'09.12.2015', '01.01.2016','09.12.2015', '01.01.2016', 23, 23)
insert into Wystawione 
	values(6, 0, 2,'09.12.2015', '01.01.2016','09.12.2015', '01.01.2016', 23, 23)
insert into Wystawione 
	values(7, 13, 1,'01.04.2019', '10.08.2019',NULL, NULL, 131, NULL)
insert into Wystawione 
	values(8, 9, 1,'01.04.2019', '10.08.2019',NULL, NULL, 131, NULL)
insert into Wystawione 
	values(9, 10, 1,'01.04.2019', '10.08.2019',NULL, NULL, 131, NULL)
	

insert into Przechowywanie
	(idPrzechowywania, idDziela, idMagazynu, dataRozpoczecia, dataZakonczenia, kosztZaDzien, uwagi)
	values(0, 0,3, '16.10.2012', '08.12.15', 10, NULL)
insert into Przechowywanie
	values(1, 10, 2, '16.05.2012', '31.03.2013', 15, NULL)
insert into Przechowywanie
	values(2, 10, 2, '11.10.2013', '8.12.2015', 15, NULL)
insert into Przechowywanie
	values(3, 10,2, '02.01.2016', '31.03.2019', 15, NULL)
insert into Przechowywanie
	values(4, 2,1, '10.04.2010', '09.04.2013', 8, NULL)
insert into Przechowywanie
	values(5, 3,1, '01.01.2010', '16.04.2013', 5, NULL)
insert into Przechowywanie
	values(6, 3,1, '26.04.2013', '10.04.2019', 3, NULL)
insert into Przechowywanie
	values(7, 3,8, '16.04.2019', '31.12.2019', 12, NULL)
insert into Przechowywanie
	values(8, 4,9, '16.10.2012', '09.01.2016', 10, NULL)
insert into Przechowywanie
	values(9, 5,2, '01.03.2010', '06.03.2010', 6, NULL)
insert into Przechowywanie
	values(10, 5,4, '22.03.2010', '08.12.2010', 6, NULL)
	
insert into Wypozyczenie 
	(idWypozyczenia, idKontrahenta,  planowanaDataRozpoczecia, planowanaDataZakonczenia, rzeczywistaDataRozpoczecia, 
	rzeczywistaDataZakonczenia, koszt) 
	values(0, 3, '10.10.2012', '15.10.2012', '10.10.2012', '15.10.2012', 4000)
insert into Wypozyczenie 
	values(1, 1, '13.01.2018', '15.10.2018', '13.01.2018', '15.10.2018', 3800)
insert into Wypozyczenie 
	values(2, 7, '18.06.2013', '16.06.2014', '18.06.2013', '16.06.2014', 2780)
insert into Wypozyczenie 
	values(3, 9, '10.10.2018', '20.12.2021', '10.10.2018', '20.12.2021', 2700)
insert into Wypozyczenie 
	values(4, 4, '16.10.2012', '20.10.2012', '16.10.2012', '20.10.2012', 2600)
insert into Wypozyczenie 
	values(5, 4, '24.10.2012', '30.10.2012', '24.10.2012', '30.10.2012', 2500)
insert into Wypozyczenie 
	values(6, 6, '16.10.2012', '20.10.2012', '16.10.2012', '20.10.2012', 2400)
insert into Wypozyczenie 
	values(7, 6, '24.10.2012', '30.10.2012', '24.10.2012', '30.10.2012', 2300)
insert into Wypozyczenie 
	values(8, 5, '01.01.2012', '01.01.2013', '01.01.2012', '01.01.2013', 2200)
insert into Wypozyczenie 
	values(9, 8, '02.01.2013', '01.01.2014', '02.01.2013', '01.01.2014', 2000)
	
	
insert into Dzielo2Wypozyczenie
	(idDziela,idWypozyczenia)
	values(1,0)
insert into Dzielo2Wypozyczenie
	values(7,0)
insert into Dzielo2Wypozyczenie
	values(6,1)
insert into Dzielo2Wypozyczenie
	values(8,2)
insert into Dzielo2Wypozyczenie
	values(11,3)
insert into Dzielo2Wypozyczenie
	values(1,4)
insert into Dzielo2Wypozyczenie
	values(1,5)
insert into Dzielo2Wypozyczenie
	values(7,6)
insert into Dzielo2Wypozyczenie
	values(7,7)
insert into Dzielo2Wypozyczenie
	values(12,8)
insert into Dzielo2Wypozyczenie
	values(12,9)