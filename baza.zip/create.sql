CREATE TABLE Epoka (
	idEpoki Integer PRIMARY KEY NOT NULL,
	nazwa VarChar(40),
	opis VarChar(400) NOT NULL,
	rokRozpoczecia SmallInt,
	rokZakonczenia SmallInt
	)

CREATE TABLE Dzielo (
	idDziela Integer PRIMARY KEY NOT NULL,
	idEpoki Integer,
	rokWykonania SmallInt,
	nazwa VarChar(100),
	wartosc Decimal (16,2) CHECK (wartosc >0),
	wlasciciel VarChar(50) NOT NULL DEFAULT 'Muzueum Sztuk Pieknych',
	zniszczonePermanentnie Bit DEFAULT 0,
	FOREIGN KEY (idEpoki) REFERENCES Epoka(idEpoki) 
	)

CREATE TABLE Autor (
	idAutora Integer PRIMARY KEY NOT NULL,
	imie VarChar(20),
	nazwisko VarChar(30),
	zyje Bit,
	dataUrodzenia DATE,
	dataSmierci DATE,
	)

CREATE TABLE Autor2Dzielo(
	idDziela Integer,
	idAutora Integer,
	PRIMARY KEY (idDziela, idAutora)
	FOREIGN KEY (idDziela) REFERENCES Dzielo(idDziela),
	FOREIGN KEY (idAutora) REFERENCES Autor(idAutora),
	)


CREATE TABLE Pracownia (
	idPracowni Integer PRIMARY KEY NOT NULL,
	powierzchnia Decimal(10,2),
	pelne Bit,
	czynnaOd time(0),
	czynnaDo time(0)
	)

CREATE TABLE Praca (
	idPracy Integer PRIMARY KEY NOT NULL,
	idDziela Integer,
	idPracowni Integer,
	planowanaDataRozpoczecia DATE NOT NULL,
	planowanaDataZakonczenia DATE NOT NULL,
	rzeczywistaDataRozpoczecia DATE,
	rzeczywistaDataZakonczenia DATE,
	planowanyCzasTrwania SmallInt CHECK (planowanyCzasTrwania >= 0) NOT NULL,
	rzeczywistyCzasTrwania SmallInt CHECK (rzeczywistyCzasTrwania >= 0),
	koszt Integer CHECK (koszt >= 0),
	rodzajPracy VarChar(30) NOT NULL,
	wToku Bit,
	skutek VarChar(200) NOT NULL DEFAULT 'Sukces',
	FOREIGN KEY (idDziela) REFERENCES Dzielo(idDziela),
	FOREIGN KEY (idPracowni) REFERENCES Pracownia(idPracowni)
	)

CREATE TABLE Wystawa(
	idWystawy Integer PRIMARY KEY NOT NULL,
	nazwa VarChar(100),
	dataWernisazu DATE,
	dataZakonczeniaWystawy DATE,
	godzinaOtwarcia time(0),
	godzinaZamkniecia time(0),
	iloscOdwiedzajacych Int CHECK (iloscOdwiedzajacych >=0)
	)

CREATE TABLE Wystawione (
	idWystawienia Integer PRIMARY KEY NOT NULL,
	idDziela Integer,
	idWystawy Integer NOT NULL,
	planowanaDataRozpoczecia DATE NOT NULL,
	planowanaDataZakonczenia DATE NOT NULL,
	rzeczywistaDataRozpoczecia DATE,
	rzeczywistaDataZakonczenia DATE,
	planowanyCzasTrwania SmallInt CHECK (planowanyCzasTrwania >= 0) NOT NULL,
	rzeczywistyCzasTrwania SmallInt CHECK (rzeczywistyCzasTrwania >= 0),
	FOREIGN KEY (idDziela) REFERENCES Dzielo(idDziela),
	FOREIGN KEY (idWystawy) REFERENCES Wystawa(idWystawy)
	)

CREATE TABLE Magazyn (
	idMagazynu Integer PRIMARY KEY NOT NULL,
	powierzchnia Decimal (12,2),
	odlegloscOdMuzuem Integer,
	pelne Bit,
	dataRozpoczeciaWspolpracy DATE
	)

CREATE TABLE Przechowywanie (
	idPrzechowywania Integer PRIMARY KEY NOT NULL,
	idDziela Integer,
	idMagazynu Integer,
	dataRozpoczecia DATE,
	dataZakonczenia DATE,
	kosztZaDzien Integer,
	uwagi VarChar(100) DEFAULT 'Brak',
	FOREIGN KEY (idDziela) REFERENCES Dzielo(idDziela),
	FOREIGN KEY (idMagazynu) REFERENCES Magazyn(idMagazynu)
	)

CREATE TABLE Kontrahent (
	idKontrahenta Integer PRIMARY KEY NOT NULL,
	nazwaInstytucja VarChar(50),
	miasto VarChar(50),
	kraj VarChar(50),
	typInstytucji VarChar(1)
	)

CREATE TABLE Wypozyczenie (
	idWypozyczenia Integer PRIMARY KEY NOT NULL,
	idKontrahenta Integer,
	planowanaDataRozpoczecia DATE NOT NULL,
	planowanaDataZakonczenia DATE NOT NULL,
	rzeczywistaDataRozpoczecia DATE,
	rzeczywistaDataZakonczenia DATE,
	koszt Integer,
	FOREIGN KEY (idKontrahenta) REFERENCES Kontrahent(idKontrahenta)
	)
	
CREATE TABLE Dzielo2Wypozyczenie(
	idDziela Integer,
	idWypozyczenia Integer,
	PRIMARY KEY (idDziela, idWypozyczenia)
	FOREIGN KEY (idDziela) REFERENCES Dzielo(idDziela),
	FOREIGN KEY (idWypozyczenia) REFERENCES Wypozyczenie(idWypozyczenia),
	)

	
CREATE NONCLUSTERED INDEX miasta
	ON Kontrahent(miasto)
	
CREATE NONCLUSTERED INDEX wlasciciele
	ON Dzielo(wlasciciel)
	
CREATE NONCLUSTERED INDEX rodzaje
	ON Praca(rodzajPracy)


